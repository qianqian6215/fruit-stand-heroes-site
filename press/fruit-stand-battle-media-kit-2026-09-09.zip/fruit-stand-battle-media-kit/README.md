# Fruit Stand Battle media kit

Updated: 2026-10-05 (text); screenshots: 2026-09-09

Fruit Stand Battle is a free five-lane defense game for iPhone, iPad and Android. Tiny fruit defenders gather Dewdrops, block, heal, control crowds, and attack while protecting their stand from hungry animals and oversized bosses.

- App Store: https://apps.apple.com/us/app/fruit-stand-battle/id6797271636
- Official website: https://fruitstandbattle.com/
- Google Play: https://play.google.com/store/apps/details?id=com.veralearn.zxx.fruitstandbattle
- Gameplay: https://youtube.com/shorts/dABHH6bomaw
- iOS release: 2026-09-04
- Price: Free
- Ads / in-app purchases: None
- Platform: iPhone, iPad and Android
- Genres: Casual, Strategy

Files:
- `01-seaside-gameplay-en-2688x1242.jpg`: full-board English gameplay screenshot.
- `02-seaside-levels-en-2688x1242.jpg`: English Chapter 1 level-select screenshot.
- `03-seaside-victory-en-2688x1242.jpg`: English victory screenshot.
- `fruit-stand-battle-icon-1024.png`: App Store icon.

The three screenshots are iOS App Store media retrieved from Apple's image CDN on 2026-09-09. The icon is the matching project marketing icon. The game owner authorized public promotional use.

# Fruit Stand Battle media kit

Updated: 2026-10-10

Fruit Stand Battle is a free five-lane tower defense game for iPhone, iPad and Android. Tiny fruit defenders gather Dewdrops, block, heal, control crowds and attack while protecting their stand from hungry animals and oversized bosses.

- App Store: https://apps.apple.com/app/fruit-stand-battle/id6797271636?pt=126491309&ct=official_press_ios_oct2026&mt=8
- Google Play: https://play.google.com/store/apps/details?id=com.veralearn.zxx.fruitstandbattle&utm_source=official_site&utm_medium=press_kit&utm_campaign=official_press_android_oct2026
- Official website: https://fruitstandbattle.com/
- Current gameplay: https://fruitstandbattle.com/press/#current-gameplay
- iOS release: 2026-09-04
- Price: Free
- Ads / in-app purchases: None
- Offline play: Yes, after installation
- Typical round: 3–5 minutes
- Platforms: iPhone, iPad and Android
- Genres: Tower defense, Casual strategy

Files:

- `01-sunny-market-full-hud.jpg`: Sunny Market gameplay with the full English HUD.
- `02-moonlit-coast-full-hud.jpg`: Moonlit Coast gameplay with the full English HUD.
- `03-cloudcrest-full-hud.jpg`: Cloudcrest gameplay with the full English HUD.
- `04-ios-seaside-gameplay.jpg`: iOS full-board English gameplay screenshot.
- `05-ios-level-select.jpg`: iOS Chapter 1 level-select screenshot.
- `06-ios-victory.jpg`: iOS victory screenshot.
- `fruit-stand-battle-icon-1024.png`: 1024×1024 app icon.

The first three images are authentic Android gameplay frames used on the official site and show the same game available on iPhone and iPad. The next three images are iOS App Store media retrieved from Apple's image CDN on 2026-09-09. The game owner authorized public promotional use.

For coverage, interviews or questions: maoqianqiansea@gmail.com
